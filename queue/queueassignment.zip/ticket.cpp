#include"node.h"
//#include"nodepr.cpp"
#include<iostream>
using namespace std;
class ticket{
	public:
	ticket(int ticketid,string description,int priority){
		this->description=description;
		this->ticketid=ticketid;
		this->priority=priority;
	}
	int ticketid;
	string description;
	int priority;
	void printdetails(){
		cout<<"TICKET ID || "<<ticketid<<"DESCRIPTION || "<<description<<"PRIORITY"<<priority;
		
	}
	
	
	
};
class ticketqueue{
	public:
	Node<ticket>*front;
	Node<ticket>*rear;
	ticketqueue() : front(nullptr), rear(nullptr) {}
	void enqueue(ticket a){
		Node<ticket>* n = new Node<ticket>(a); 
		if(isempty()){
		front=rear=n;
		}
		else if(a.priority<front->getData().priority){   //add at first
			n->setNextPtr(front);
			front=n;
		}
		else if(a.priority>rear->getData().priority){   // add At last
			  rear->setNextPtr(n);
			  rear=n;
		}
		else{                                 // add at k position
		    
		    Node<ticket>*current=rear;
		    Node<ticket>*prev=NULL;
			while(current->getData().priority<=a.priority){
				prev=current;
				current=current->getNextPtr();
			}
			prev->setNextPtr(n);
			n->setNextPtr(current);			
	}
	}
	void dequeue(){
		if(isempty()){
			cout<<"queue underflow";
			return;
		}
		Node<ticket>*todequeue=front;
		front=front->getNextPtr();
		delete todequeue;
		return;
	
		
	}
	bool isempty(){
		if(front==NULL){
			return true;
		}
		else 
		return false;
	}
	void getqueuesize(){
		Node<ticket>*current=front;
		int size=0;
		while(current!=NULL){
			size++;
			current=current->getNextPtr();
		}
		cout<<size;
	}
	void printqueue(){
		if(isempty()){
			cout<<"Queue is empty";
			return;
		}
		else{
		
		Node<ticket>*current=front;
		while(current!=NULL){
		current->getData().printdetails();
			current=current->getNextPtr();
		
		}
	}}
};
int main(){
	    ticketqueue ticketQueue;
	ticket ticket1(1, "Internet nahi", 2);
    ticket ticket2(2, "nstallation problem", 1);
    ticket ticket3(3, "xncns", 3);

    ticketQueue.enqueue(ticket1);
    ticketQueue.enqueue(ticket2);
    ticketQueue.enqueue(ticket3);


    return 0;
}